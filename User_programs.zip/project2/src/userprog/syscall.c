#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"

#include "threads/vaddr.h"
#include "threads/init.h"
#include "userprog/process.h"
#include <list.h>
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "threads/palloc.h"
#include "threads/malloc.h"
#include "devices/input.h"
#include "threads/synch.h"

static void syscall_handler (struct intr_frame *);


typedef int pid_t;

 int system_call_write (int fd, const void *buffer, unsigned length);
 int system_call_halt (void);
 int system_call_create (const char *file, unsigned initial_size);
 int system_call_open (const char *file);
 void system_call_close (int fd);
 int system_call_read (int fd, void *buffer, unsigned size);
 int system_call_exec (const char *cmd);
 int system_call_wait (pid_t pid);
 int system_call_filesize (int fd);
 int system_call_tell (int fd);
 void system_call_seek (int fd, unsigned pos);
 bool system_call_remove (const char *file);
 bool check_address(void *vaddr);
 // function to check the validity of the address passed to it
 bool check_address(void *vaddr)
 {
 return is_user_vaddr(vaddr);
 }
// function to search for the file with the given fd
 struct file *search_file (int fd);
// function to search for the file_info structure with the provided fd 
 struct file_info *search_file_info (int fd);
 //int alloc_fid (void);
// function to search for the file_info structure with the provided fd in the currently running process
 struct file_info *search_file_in_process (int fd);

int file_descriptor=2;          // defining the file descriptor so as to assign to newly opened file
 struct lock lock1;

struct file_info               // a structure to store the information of every file
  {
    int fd;
    struct file *file;
    struct list_elem elem;
    struct list_elem t_elem;
  };
  
static struct list open_file_list;    //list to store the opened file at any instant


void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
  
  list_init (&open_file_list);
  lock_init (&lock1);

}

static void
syscall_handler (struct intr_frame *f) 
{
//printf("in handler\n");
  int *n;
  n=f->esp;

 if (!is_user_vaddr (n))
    system_call_exit(-1);
//----------------------------
//if(*n==NULL)
  //system_call_exit(-1);
//printf("number is %d\n",*(int*)NULL);
//----------------------------

//  checking if the number of the system call is valid or not
if (*n < SYS_HALT || *n > SYS_INUMBER)
    system_call_exit(-1);
  
// check the validity 
  if (!(check_address (n + 1) && check_address (n + 2) && check_address (n + 3)))
  //if (!(check_address (n + 1) || check_address (n + 2) || check_address (n + 3)))    
	system_call_exit(-1);


// passing the control to the different system call according to the esp given in the frame pointer
if(*n==SYS_HALT)
{
//printf("SYS HALT\n");	
	system_call_halt();
	f->eax=NULL;
}
if(*n==SYS_EXIT)
{
//printf("SYS EXIT\n");	
	system_call_exit(*(n+1));
	f->eax=NULL;
}
if(*n==SYS_EXEC)
{
//printf("SYS EXEC\n");	
	pid_t r=system_call_exec (*(n+1));
	f->eax=r;
}
if(*n==SYS_CREATE)
{
//printf("SYS CREATE\n");	
	bool b=system_call_create(*(n+1),*(n+2));
	if(b)
		f->eax=1;
	else
		f->eax=0;

}
if(*n==SYS_REMOVE)
{
//printf("SYS REMOVE\n");	
	bool b1=system_call_remove(*(n+1));
	if(b1)
		f->eax=1;
	else
		f->eax=0;
}
if(*n==SYS_OPEN)
{
//printf("SYS OPEN\n");	
	int r1=system_call_open(*(n+1));
	f->eax=r1;
}
if(*n==SYS_FILESIZE)
{
//printf("SYS FILESIZE\n");	
	int r2=system_call_filesize(*(n+1));
	f->eax=r2;
}
if(*n==SYS_READ)
{
//	printf("SYS READ\n");	
	int r3=system_call_read(*(n+1),*(n+2),*(n+3));
	f->eax=r3;
}
if(*n==SYS_WRITE)
{
//	printf("SYS WRITE\n");
	int r3=system_call_write(*(n+1),*(n+2),*(n+3));
	f->eax=r3;
}
if(*n==SYS_SEEK)
{
//printf("SYS SEEK\n");	
	system_call_seek(*(n+1),*(n+2));
	f->eax=NULL;
}
if(*n==SYS_TELL)
{
//printf("SYS TELL\n");	
	unsigned  r3=system_call_tell(*(n+1));
	f->eax=r3;
}
if(*n==SYS_WAIT)
{
//printf("SYS TELL\n");	
	int  r3=system_call_wait(*(n+1));
	f->eax=r3;
}
if(*n==SYS_CLOSE)
{
//printf("SYS CLOSE\n");	
	system_call_close(*(n+1));
	f->eax=NULL;
}

  //printf ("system call!\n");
 // thread_exit ();
return;

}

int
system_call_write (int fd, const void *buffer, unsigned length)
{
//printf("system call write\n");	
  struct file * f;
  int ret;
  
  ret = -1;
  lock_acquire (&lock1);
//printf("test\n");
  if (fd == STDOUT_FILENO)      //write mode
  {
//	printf("test3\n");
    putbuf (buffer, length);
//	printf("test3\n");
  }
  else if (fd == STDIN_FILENO)   //read mode
  {
//	printf("test4\n");
	  lock_release (&lock1);
	  //printf("check\n");  
	  return ret;
  }
  else if (!check_address (buffer) || !check_address (buffer + length))
    {
//	printf("test2\n");
      lock_release (&lock1);
      system_call_exit (-1);
    }
  else
    {
      f = search_file (fd);
      if (!f)               //if file not found then exiting
	{
		  lock_release (&lock1);
	  //printf("check\n");  
	  return ret;

	}
//	printf("just before write system call\n");        
      ret = file_write (f, buffer, length);
    }

//done:
  lock_release (&lock1);
  //printf("check\n");  
  return ret;
}

int
system_call_exit (int status)
{
  //printf("exit system call \n");
  
  struct thread *t;
  struct list_elem *l;
  
  t = thread_current ();
  while (!list_empty (&t->files))            //closing all the files opened by the currently exiting thread
    {
      l = list_begin (&t->files);
      system_call_close (list_entry (l, struct file_info, t_elem)->fd);
    }
  
  t->ret_status = status;
  thread_exit ();
  return t->ret_status;
//return -1;
}

int
system_call_halt (void)
{
//printf("halt system call \n");
  shutdown_power_off ();
}

 int
system_call_create (const char *file, unsigned initial_size)
{
//printf("create system call \n");
  if (!file)
    return system_call_exit (-1);
  return filesys_create (file, initial_size);      //creating the file
}

 int
system_call_open (const char *file)
{
//printf("open system call \n");
  struct file *f;
  struct file_info *fde;
  int ret;
  
  ret = -1; 	
  if (!file)              // if file is null 
    return -1;
  if (!check_address (file))
    system_call_exit (-1);
  f = filesys_open (file);
  if (!f) 			// if invalid file name */
    return ret;
    
  fde = (struct file_info *)malloc (sizeof (struct file_info));
  if (!fde) /* Not enough memory */
    {
      file_close (f);
      return ret;
    }
    
  fde->file = f;
  fde->fd = file_descriptor;              //assigning the file descriptor 
	file_descriptor++;		// incrementing the file_descriptor	
  list_push_back (&open_file_list, &fde->elem);     // pushing the elem in the open file list
  list_push_back (&thread_current ()->files, &fde->t_elem);   //pushing the t_elem in the open file list of the currently running thread 
  ret = fde->fd;

  return ret;
}

 void
system_call_close(int fd)
{
//printf("close system call \n");
  struct file_info *f;
  int ret;
  
  f = search_file_in_process (fd);
  
  if (!f) // file does not exist
//---------------------------------------------------------------------------
	return;
//------------------------------------------------------------------------------
    //goto done;
  file_close (f->file);
  list_remove (&f->elem);
  list_remove (&f->t_elem);
  free (f);
  

return;
}

 int
system_call_read (int fd, void *buffer, unsigned size)
{
//printf("read system call \n");
  struct file * f;
  unsigned i;
  int ret;
  
  ret = -1; 
  lock_acquire (&lock1);
  if (fd == STDIN_FILENO) 	// read mode
    {
      for (i = 0; i != size; ++i)
        *(uint8_t *)(buffer + i) = input_getc ();
      ret = size;
      goto done;
    }
  else if (fd == STDOUT_FILENO) // write mode
      goto done;
  else if (!check_address (buffer) || !check_address (buffer + size)) // 
    {
      lock_release (&lock1);
      system_call_exit (-1);
    }
  else
    {
      f = search_file (fd);
      if (!f)
        goto done;
      ret = file_read (f, buffer, size);
    }
    
done:    
  lock_release (&lock1);
  return ret;
}

 int
system_call_exec (const char *cmd)
{
//printf("exec system call \n");
  int ret;
  
  if (!cmd || !check_address (cmd)) //check the validity of pointers
  {  
    //printf("invalid pointer\n");
	return -1;
  }
//printf("exec\n");
  lock_acquire (&lock1);
  ret = process_execute (cmd);
  lock_release (&lock1);
  return ret;
}

 int
system_call_wait (pid_t pid)
{
//printf("wait system call \n");
  return process_wait (pid);
}


// function to search for the file with the given fd
struct file *search_file (int fd)
{
  struct file_info *ret;
  
  ret = search_file_info (fd);
  if (!ret)
    return NULL;
  return ret->file;
}


// function to search for the file_info structure with the provided fd 
 struct file_info *
search_file_info (int fd)
{
  struct file_info *ret;
  struct list_elem *l;
  
  for (l = list_begin (&open_file_list); l != list_end (&open_file_list); l = list_next (l))
    {
      ret = list_entry (l, struct file_info, elem);
      if (ret->fd == fd)
        return ret;
    }
    
  return NULL;
}




 int
system_call_filesize (int fd)
{
//printf("system call filesize");
  struct file *f;
  
  f = search_file (fd);
  if (!f)
    return -1;
  return file_length (f);
}

 int
system_call_tell (int fd)
{
//printf("system call tell");
  struct file *f;
  
  f = search_file (fd);
  if (!f)
    return -1;
  return file_tell (f);
}

void
system_call_seek (int fd, unsigned pos)
{
//printf("system call seek");
  struct file *f;
  
  f = search_file (fd);
  if (!f)
    //return -1;
	return;  
file_seek (f, pos);
  //return 0;
   return; 
}

bool
system_call_remove (const char *file)
{
//printf("system call remove");
  if (!file)
    return false;
  if (!check_address (file))
    system_call_exit (-1);
    
  return filesys_remove (file);
}

// function to search for the file_info structure with the provided fd in the currently running process
struct file_info *
search_file_in_process (int fd)
{
  struct file_info *ret;
  struct list_elem *l;
  struct thread *t;
  
  t = thread_current ();
  
  for (l = list_begin (&t->files); l != list_end (&t->files); l = list_next (l))
    {
      ret = list_entry (l, struct file_info, t_elem);
      if (ret->fd == fd)
        return ret;
    }
    
  return NULL;
}
