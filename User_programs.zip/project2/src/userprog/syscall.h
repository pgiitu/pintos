#ifndef USERPROG_SYSCALL_H
#define USERPROG_SYSCALL_H

void syscall_init (void);
int system_call_exit (int status);

#endif /* userprog/syscall.h */


