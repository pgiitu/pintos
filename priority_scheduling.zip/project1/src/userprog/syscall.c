#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/vaddr.h"
#include "threads/init.h"
#include "userprog/process.h"
#include <list.h>
#include "filesys/file.h"
#include "filesys/filesys.h"
#include "threads/palloc.h"
#include "threads/malloc.h"
#include "devices/input.h"
#include "threads/synch.h"

typedef int pid_t;
static void syscall_handler (struct intr_frame *);
void halt (void);
int exit (int status);
pid_t exec (const char *cmd_line);
//int exec (const char *cmd_line);
bool create (const char *file, unsigned initial_size);
int remove (const char *file);
int open (const char *file_name);
struct file_info *  find_file (int fd);
int filesize (int fd);
int read (int fd, void *buffer, unsigned size);
int write (int fd, const void *buffer, unsigned size);
void seek (int fd, unsigned position);
void close (int fd);
void close (int fd);
int wait (pid_t pid);

struct lock lock1;
struct list open_file_list;
int file_descriptor=2;
struct file_info
{
	struct file *f;
	int fd;
	struct list_elem t_elem;
	struct list_elem elem;
};

void syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
  lock_init(&lock1);
  list_init(&open_file_list);
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  //printf("entered syscall_handler\n");
  int *n;
  n=f->esp;


//  checking if the number of the system call is valid or not
if (*n < SYS_HALT || *n > SYS_INUMBER)
    thread_exit();
  
// check the validity 
  if (!(is_user_vaddr (n + 1) && is_user_vaddr (n + 2) && is_user_vaddr (n + 3)))
    thread_exit();

  //printf("System call no is %d \n",*n);	
  //printf("System call no is %d \n",SYS_HALT);
if(*n==SYS_HALT)
{
//printf("SYS HALT\n");	
	halt();
	f->eax=NULL;
}
if(*n==SYS_EXIT)
{
//printf("SYS EXIT\n");	
	exit(*(n+1));
	f->eax=NULL;
}
if(*n==SYS_EXEC)
{
//printf("SYS EXEC\n");	
	pid_t r=exec (*(n+1));
	f->eax=r;
}
if(*n==SYS_CREATE)
{
//printf("SYS CREATE\n");	
	bool b=create(*(n+1),*(n+2));
	if(b)
		f->eax=1;
	else
		f->eax=0;

}
if(*n==SYS_REMOVE)
{
//printf("SYS REMOVE\n");	
	bool b1=remove(*(n+1));
	if(b1)
		f->eax=1;
	else
		f->eax=0;
}
if(*n==SYS_OPEN)
{
//printf("SYS OPEN\n");	
	int r1=open(*(n+1));
	f->eax=r1;
}
if(*n==SYS_FILESIZE)
{
//printf("SYS FILESIZE\n");	
	int r2=filesize(*(n+1));
	f->eax=r2;
}
if(*n==SYS_READ)
{
//printf("SYS READ\n");	w
	int r3=read(*(n+1),*(n+2),*(n+3));
	f->eax=r3;
}
if(*n==SYS_WRITE)
{
	//printf("SYS WRITE\n");	
	int r3=write(*(n+1),*(n+2),*(n+3));
	f->eax=r3;
}
if(*n==SYS_SEEK)
{
//printf("SYS SEEK\n");	
	seek(*(n+1),*(n+2));
	f->eax=NULL;
}
if(*n==SYS_TELL)
{
//printf("SYS TELL\n");	
	//unsigned  r3=tell(*(n+1));
	//f->eax=r3;
}
if(*n==SYS_WAIT)
{
//printf("SYS TELL\n");	
	//int  r3=wait(*(n+1));
	//f->eax=r3;
}
if(*n==SYS_CLOSE)
{
//printf("SYS CLOSE\n");	
	close(*(n+1));
	f->eax=NULL;
}

  //printf ("system call!\n");
 // thread_exit ();
return;
}
//--------------------------------HALT System Call--------------------------------------------------------
void halt (void)
{
	printf("system halt \n");
	shutdown_power_off();

}
//--------------------------------EXIT System Call--------------------------------------------------------
int exit (int status)
{
 printf("EXIT SYSTEM CALL:-calling with value %d \n",status);
  struct thread *t;
  struct list_elem *e;
 //printf("EXit 111111 \n");
  
  t = thread_current ();
  while (!list_empty (&t->file_list))                     //closing all the files opened by the thread by going through the list
    {
      e = list_begin (&t->file_list);
      close (list_entry (e, struct file_info, t_elem)->fd);
    }
//printf("EXIT end SYSTEM CALL \n");
    t->ret_status = status;
  thread_exit ();
//printf("EXIT extreme end SYSTEM CALL \n");
  return t->ret_status;

	//struct file *f1;
}


//--------------------------------EXEC System Call--------------------------------------------------------

pid_t exec (const char *cmd_line)
{
printf("system call exec \n");
if (!cmd_line || !is_user_vaddr (cmd_line))             //     for an invalid pointer
{   
 return -1;// original
return exit(-1);
}
int t;
lock_acquire_system(&lock1);
t=process_execute(cmd_line);
lock_release_system(&lock1);
return t;	
}


//--------------------------------CREATE System Call--------------------------------------------------------
bool create (const char *file, unsigned initial_size)
{
printf("CREATE system call \n");
  if (!file)
    return exit (-1);
  return filesys_create(file,initial_size);
}


//--------------------------------REMOVE System Call--------------------------------------------------------
int remove (const char *file)
{
printf("REMOVE system call \n");
  if (!file)
    return 0;
  if (!is_user_vaddr (file))
    return exit (-1);
  return filesys_remove (file);
}


//--------------------------------OPEN System Call--------------------------------------------------------
int open (const char *file_name)
{
  printf("OPEN system call \n");
  if (!file_name) /* file == NULL */
    return -1;
  if (!is_user_vaddr (file_name))
    exit (-1);
	//printf("aa\n");
	struct file *file_new;
	int return_value=-1;
	struct file_info *fi1;	
  	fi1 = (struct file_info *)malloc (sizeof (struct file_info));
	file_new=filesys_open(file_name);
	if(file_new)
	{
		printf("aa\n");
		fi1->f=file_new;
		printf("aa\n");
		fi1->fd=file_descriptor;
		file_descriptor++;
		printf("aa\n");
		list_push_back (&open_file_list, &fi1->elem);
		list_push_back (&thread_current()->file_list, &fi1->t_elem);
		return_value=fi1->fd;
		return return_value;
	}
	else
	{
		return -1;
	}
//return return_value;


/*
  struct file *f;
  struct file_info *fde;
  int ret;  
  ret = -1;        // Initialize to -1 
  if (!file_name)        // file == NULL 
    return -1;
  if (!is_user_vaddr (file_name))
    sys_exit (-1);
  f = filesys_open (file_name);
  if (!f)          // Bad file name 
    goto done;
    
  fde = (struct fd_elem *)malloc (sizeof (struct fd_elem));
  if (!fde) // Not enough memory 
    {
      file_close (f);
      goto done;
    }
    
  fde->file = f;
  fde->fd = alloc_fid ();
  list_push_back (&file_list, &fde->elem);
  list_push_back (&thread_current ()->files, &fde->thread_elem);
  ret = fde->fd;
done:
  return ret;*/
}
/* function to find the file corresponding to  given file_descriptor as fd*/
struct file_info *  find_file (int fd)
{
	struct list_elem *e;
	struct file_info *fo;
	for (e = list_begin (&open_file_list); e != list_end (&open_file_list); e = list_next (e))
	{
		fo=list_entry(e,struct file_info,elem);
		if(fo->fd==fd)
			return fo;
	}
	return NULL;
}
//--------------------------------FILESIZE System Call--------------------------------------------------------
int filesize (int fd)
{
printf("FILESIZE system call \n");
	struct file_info *fo;
	struct file *file_new;
	fo=find_file(fd);
	if(!fo)
	{
		file_new=fo->f;
		return file_length(file_new);	
	}
	return -1;
}


//--------------------------------READ System Call--------------------------------------------------------
int read (int fd, void *buffer, unsigned size)
{
//printf("READ system call \n");
/*	int k=-1;	
	lock_acquire_system(&lock1);
	if(fd==0)
	{
		int i;      		
		for (i = 0; i != size; ++i)
        		*(uint8_t *)(buffer + i) = input_getc ();
      		k = size;	
		return k;
	}
	if(fd==1)
	{
		return k;	
	}
	struct file_info *fo;	
	struct file *file_new;
	fo=find_file(fd);
	if(!fo)
	{
		file_new=fo->f;
		k = file_read (file_new, buffer, size);
	}
	lock_release_system(&lock1);
return k;
*/
  struct file * f;
struct file_info *fo;
  unsigned i;
  int ret;
 // printf("1 /n");   
  
  ret = -1;       // Initialize to zero 
  lock_acquire (&lock1);
  if (fd == STDIN_FILENO)             // stdin 
    {
   //printf("1 /n");   
   for (i = 0; i != size; ++i)
        *(uint8_t *)(buffer + i) = input_getc ();
      ret = size;
      goto done;
    }
  else if (fd == STDOUT_FILENO)          // stdout 
      goto done;
  else if (!is_user_vaddr (buffer) || !is_user_vaddr (buffer + size))   // bad ptr 
    {
      lock_release (&lock1);
      exit (-1);
    }
  else
    {
  // printf("1 /n");   
      fo = find_file(fd);
      if (!f)
        goto done;
      ret = file_read (fo->f, buffer, size);
    }
    
done:    
  lock_release (&lock1);
  return ret;
}


//--------------------------------WRITE System Call--------------------------------------------------------
int write (int fd, const void *buffer, unsigned size)
{
//printf("WRITE system call \n");
//printf(" the value of size is %d \n",size);
/*	int k=0;	
	lock_acquire_system(&lock1);
	if(fd==1)
	{
		//printf(" 1 \n");
        	putbuf (buffer, size);
		//printf("%s \n",buffer);
		k=size;
		lock_release_system(&lock1);
		//printf(" 2 \n");
		//printf(" the value of k is  %d \n",k);
		return k;
	}
	if(fd==0)
	{
		printf(" 2 \n");
		lock_release_system(&lock1);
		return k;	
	}
	printf(" 3 \n");
	struct file_info *fo;	
	struct file *file_new;
	fo=find_file(fd);
	printf(" 4 \n");
	if(!fo)
	{
	printf(" 4 \n");

		file_new=fo->f;
		k = file_write (file_new, buffer, size);
	}
	lock_release_system(&lock1);
return k;
*/
//printf("buffer is %s \n",buffer);
struct file * f;
  int ret;
  struct file_info *fo;
  ret = -1;
  lock_acquire (&lock1);
  if (fd == STDOUT_FILENO) /* stdout */
{
        //printf("1\n");
    putbuf (buffer, size);}
  else if (fd == STDIN_FILENO) /* stdin */
    goto done;
  else if (!is_user_vaddr (buffer) || !is_user_vaddr (buffer + size))
    {
      lock_release (&lock1);
      exit (-1);
    }
  else
    {
      fo = find_file (fd);
      if (!fo->f)
        goto done;
        //printf("1\n");
      ret = file_write (fo->f, buffer, size);
    }
    
done:
  lock_release (&lock1);
return ret;
}


//--------------------------------SEEK System Call--------------------------------------------------------
void seek (int fd, unsigned position)
{
//printf("SEEK system call \n");
	struct file_info *fi;
  
  fi = find_file (fd);
  if (fi->f)
  	file_seek (fi->f, position);

}


//--------------------------------TELL System Call--------------------------------------------------------
unsigned tell (int fd)
{
//printf("TELL system call \n");
  struct file_info *fi;
  
  fi = find_file(fd);
  if (!fi->f)
    return -1;
   else
	  return file_tell (fi->f);
}
//------------------------------------WAIT System call------------------------------------
int wait (pid_t pid)
{
  return process_wait (pid);
}


//--------------------------------CLOSE System Call--------------------------------------------------------
void close (int fd)
{
	//printf("CLOSE system call \n");
	struct file_info *fi;
	fi=find_file(fd);
	if(fi->f)
	{
		  file_close (fi->f);
	  	  list_remove (&fi->elem);
	  	  list_remove (&fi->t_elem);
	}	
}
